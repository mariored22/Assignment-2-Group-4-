# usage: go.sh <name_of_prog> assumed in dir ./progs
export TARGET="out/production/IP"
rm -r -f $TARGET/iProlog
rm -f progs/*.pl.nl

